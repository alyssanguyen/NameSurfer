 (ns users
      (:use takehomexam.core)
      (:require [clojure.java.io :as io]
                [clojure.string :as str]
                [clojure.pprint :refer (pprint)]
                [clojure.repl :refer :all]
                [clojure.test :as test])
 )
