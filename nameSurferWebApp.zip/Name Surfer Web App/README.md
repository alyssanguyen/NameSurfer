Welcome to the Name Surfer Web Application

This web app uses a database file to search for the top 1000 names of the decade and output the data into a graph. 