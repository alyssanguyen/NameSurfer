var graph_data = [50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50];
var years = ['1900', '1910', '1920', '1930', '1940', '1950', '1960', '1970', '1980', '1990', '2000'];
var name = null;
for (var i = 0; i < graph_data.length; i++){
    graph_data[i] = [years[i], graph_data[i]];
}

$(document).ready(function(){
    $("form").submit(function(e){
        e.preventDefault();
        var name = $("#name").val();
        //alert('got data: ' + name);
        $.ajax({
            url:'http://localhost:3000/lookup',
            type: 'POST',
            data: $(this).serialize(),
            success: function(data) {
                //alert('resp:'+data);
                var myArray = data.split(" ");
                //alert('myArray:' +myArray + myArray.length);
                for(var i=0; i<myArray.length; i++) { myArray[i] = parseInt(myArray[i], 10); }
                for (var i = 0; i < myArray.length; i++){
                    myArray[i] = [years[i], myArray[i]];
                }
                graph_data = myArray;
                //alert('split:' + graph_data[0] + graph_data[1] + graph_data[2] + graph_data[3] + graph_data[4] + graph_data[5] + graph_data[6] + graph_data[7] + graph_data[8] + graph_data[9] + graph_data[10] );
                //if (graph_data.length == 0)
                drawChart();
            },
            error: function(){
                window.alert('Baby name ' + name + 'does not exist. Try again.');
            }
        });
        e.preventDefault();
    });
});

function encodeID(s) {
    if (s==='') return '_';
    return s.replace(/[^a-zA-Z0-9.-]/g, function(match) {
        return '_'+match[0].charCodeAt(0).toString(16)+'_';
    });
}
google.charts.load('current', {'packages':['corechart', 'line']});
google.charts.setOnLoadCallback(drawChart);
function drawChart(){
    var name1 = 'Patty';
    var data = new google.visualization.DataTable();
    var years = ['1900', '1910', '1920', '1930', '1940', '1950', '1960', '1970', '1980', '1990', '2000'];
    var data1 = [50, 69, 99, 131, 168, 236, 278, 380, 467, 488, 466];
    for (var i = 0; i < data1.length; i++){
        data1[i] = [years[i], data1[i]];
    }
    data.addColumn('string', 'Year');
    data.addColumn('number', name1 );

    data.addRows(graph_data);
    var linearOptions = {
                title: 'Database from children born in the United States',
                legend: 'none',
                colors:['#FF33C5','#33FFBB'],
                hAxis: {
                    title: 'Year',
                },
                vAxis: {
                    direction: -1,
                    title: 'Popularity',
                    ticks: [1, 200, 400, 600, 800, 1000, 1010]
                },
                width: 1000,
                height: 500
    };
    var chart = new
        google.visualization.LineChart(document.getElementById('linechart_material'));
    chart.draw(data, linearOptions);
}
