(ns takehomexam.handler
  (:require [compojure.core :refer :all]
            [compojure.route :as route]
            [ring.middleware.defaults :refer [wrap-defaults site-defaults]]
            [ring.middleware.reload :refer [wrap-reload]]
            [ring.middleware.params :refer [wrap-params]]
            [compojure.core                 :only [defroutes GET POST]]
            [ring.middleware.absolute-redirects :refer [wrap-absolute-redirects]]
            [ring.middleware.keyword-params :refer [wrap-keyword-params]]
            [ring.middleware.multipart-params :as mp]
            [clojure.java.io :as io]
            [takehomexam.views :as views])
  )

(defroutes app-routes
           (GET "/" [] (views/welcome))
           (GET "/home" [] (views/home))
           (POST "/lookup" req (let [name (get (:params req) :name)] (views/search name)) )
           (route/not-found "Not Found"))

(def app
  (wrap-defaults app-routes (assoc-in site-defaults [:security :anti-forgery] false))  )

