(ns f.core
  (:require [clojure.string :as string]
            [clojure.browser.net :as net]
            [clojure.browser.event :as event]
            [cljs.reader :as reader]
            [goog.Uri.QueryData :as query-data]
            [goog.structs :as structs])
  )

(enable-console-print!)

(println "Hello world!")
