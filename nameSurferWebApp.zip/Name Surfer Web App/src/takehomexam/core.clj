(ns takehomexam.core
  (:require [korma.core :refer :all]
            [korma.db :refer :all])
  )

(def db (sqlite3 {:db "resources/namesdata.db"}))
(defentity girlsboystable (database db))

