(ns takehomexam.views
  (:require [hiccup.page :refer [html5 include-js include-css]]
            [hiccup.core :refer [html]]
            [hiccup.form :refer :all]
            [clojure.java.jdbc :as jdbc]
            [korma.core :refer :all]
            [clojure.java.io :as io]
            [ring.middleware.multipart-params]
            [ring.middleware.params]
            [cljs.build.api]
            [ajax.core :refer [GET POST]]
            [korma.db :refer :all]                          ;SQL for Clojure
            )
  )
;(cljs.build.api/build "src" {:output-to "out/main.js"})
(def db (sqlite3 {:db "./resources/namesdata.db"}))
(defentity girlsboystable (database db))


(def currentuser (atom nil))

(defn base-page
  [title & body]
  (html5
    [:head
     (include-js "https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js")
     (include-css "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css")
     (include-css "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css")
     (include-js "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js")
     ;(include-js "/barfinal.js")
     (include-css "/barfinalexam.css")
     [:title title]
     ]
    [:body.container
     [:br] [:br]
     [:br]
     [:h1 "Name Surfer Web App"]
     [:br]
     [:h3 "Group: Patricia Casagrande, Alyssa Nguyen"]
     [:br]
     (seq body)]))


(defn welcome
  []
  (base-page "Welcome Page"
             [:form {:action "/home"}
              [:button.btn.btn-info {:type "submit"} "Welcome!"] [:br] [:br]
              ]
             ))


(defn search [name]
  (def found
    (first
      (select girlsboystable
              (where {:name name})))
    )
  (if (= nil found) (do {:status 300
                         :headers {"Content-Type" "text/plain"}
                         :body "None"})
                    (do
  {:status 200
   :headers {"Content-Type" "text/plain"}
   :body (str (get found :1900) " "
              (get found :1910) " "
              (get found :1920) " "
              (get found :1930) " "
              (get found :1940) " "
              (get found :1950) " "
              (get found :1960) " "
              (get found :1970) " "
              (get found :1980) " "
              (get found :1990) " "
              (get found :2000))} )
) )
  ;(base-page "Graph"
  ;           [:h1 "found record for " name ": " found]
  ;           (if (= nil (get found :name))
  ;             (do [:a {:href "/check"} "Name was not found! Click here to try again"])
  ;             (do [:a {:href "/home"} "Success! "]))))

(defn base-page1
  [title & body]
  (html5
    [:head
     (include-js "https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js")
     (include-css "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css")
     (include-css "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css")
     (include-js "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js")
     (include-js "https://www.gstatic.com/charts/loader.js")
     (include-css "/barfinalexam.css")
     [:script {:type "text/javascript" :src "/barfinal.js"}]
     ;; [:link {:rel "stylesheet" :type "text/css" :href "/resources/public/finalp.css"}]
     [:title title]]
    [:body.container
     [:nav {:class "navbar navbar-inverse navbar-fixed-top"}
      [:div {:class "container-fluid"}
       [:div {:class "navbar-header"}
        [:button {:class "navbar-toggle " :type "button" :data-toggle "collapse" :data-target "#myNavbar"}]]
       [:nav {:id "#myNavbar" :class "collapse navbar-collapse"}
        [:ul {:class "nav navbar-nav"}
         ;; [:li {:class "active"} [:a {:href "#"}] "home"]
         ]
        [:ul {:class "nav navbar-nav navbar-right"}]]]]
     [:br] [:br]
     [:br]
     [:h1 "Take Home Final Exam"]
     [:br]
     [:h3 "Group: Patricia Casagrande, Alyssa Nguyen"]
     [:br]
     (seq body)
     [:div {:id "linechart_material" :style "width: 900px; height: 500px;"}]]))


;(defn handler [response]
;  (.log console (str response)))

(defn input [attrs]
  [:div
   [:label {:for (:field attrs) :class "control-label"} (:label attrs)]
   [:input {:type        (or (:type attrs) "text")
            :class       "form-control"
            :id          (:field attrs)
            :name        (:field attrs)
            :placeholder (:label attrs)}]])

(defn home
  []
  (base-page1 "Home Page"
              [:div {:class "row"}
               [:div {:class "col-sm-9 col-lg-10"}
                [:div {:class "col-sm-3"}
                 [:form {:method "POST" :id "f1" :action ""}
                  [:div {:class "form-group"} (input {:field "name" :label "Insert a name"})]
                  [:div {:class "form-group"} [:button {:type "submit" :class "btn btn-info"} "Get data!"]]
                  ]]]]))

